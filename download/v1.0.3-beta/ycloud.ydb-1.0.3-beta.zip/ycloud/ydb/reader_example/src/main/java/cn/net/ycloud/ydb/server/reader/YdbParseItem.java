package cn.net.ycloud.ydb.server.reader;

import java.util.Map;

public class YdbParseItem {


	Map<String,Object> doc;
	String tableName;
	String partion;
	int datasize;

	public YdbParseItem(Map<String, Object> doc, String tableName,
			String partion, int datasize) {
		super();
		this.doc = doc;
		this.tableName = tableName;
		this.partion = partion;
		this.datasize = datasize;
	}
	
	public Map<String, Object> getDoc() {
		return doc;
	}
	public String getTableName() {
		return tableName;
	}
	public String getPartion() {
		return partion;
	}
	
	
	public int getDatasize() {
		return datasize;
	}
	
	
	@Override
	public String toString() {
		return "YdbParseItem [doc=" + doc + ", tableName=" + tableName
				+ ", partion=" + partion + ", datasize=" + datasize + "]";
	}


}
