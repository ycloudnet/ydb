package cn.net.ycloud.ydb.server.reader.kafka;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.solr.store.hdfs.HdfsFileWriter;

import com.alipay.bluewhale.core.utils.StormUtils;

import cn.net.ycloud.ydb.server.reader.RawDataReader;
import cn.net.ycloud.ydb.utils.HadoopUtil;
import cn.net.ycloud.ydb.utils.RefreshCheck;
import cn.net.ycloud.ydb.utils.UniqConfig;
import cn.net.ydbmix.ydb.core.utils.Utils;
import cn.net.ydbmix.ydb.time.DateFormatUtils;



public class KafkaDataReader implements RawDataReader {
    private static final Log LOG = LogFactory.getLog(KafkaDataReader.class.getName());

	private transient LinkedBlockingQueue<String> messageQueue=new LinkedBlockingQueue<String>(10240);
    private ConsumerGroup kafka=null;
    Path path;
    
    private boolean isBackup=false;
	public RefreshCheck refreshCheck=null;

	@Override
	public void init(String prefix,Map config, int readerIndex, int readerCount)
			throws IOException {

		final int queueMaxsize=Utils.parseInt(String.valueOf(config.get("kafka.queue.size"+prefix)));
		final String topic=String.valueOf(config.get("kafka.topic"+prefix));
		final String zkstr=String.valueOf(config.get("kafka.zookeeper"+prefix));
		final String group=String.valueOf(config.get("kafka.group"+prefix));
		final String reset=String.valueOf(config.get("kafka.auto.offset.reset"+prefix));
		this.isBackup=Boolean.parseBoolean(String.valueOf(config.get("kafka.backup.rawdata"+prefix)));

		final int threads=Utils.parseInt(String.valueOf(config.get("kafka.threads"+prefix)));

		this.messageQueue = new LinkedBlockingQueue<String>(queueMaxsize);
    	this.kafka = new ConsumerGroup(zkstr,group,topic,reset);
    	this.kafka.run(this,threads);
    	
    	Object oscrollsecs=config.get("kafka.backup.scroll.secs"+prefix);
    	if(oscrollsecs==null)
    	{
    		oscrollsecs="3600";
    	}
		final int scrollsecs=Utils.parseInt(String.valueOf(oscrollsecs));
		
		
	 	Object oscrollsize=config.get("kafka.backup.scroll.size"+prefix);
    	if(oscrollsize==null)
    	{
    		scrollSize=1024l*1024*1024;
    	}else
    	{
    		scrollSize=Utils.parseLong(String.valueOf(oscrollsize));
    	}

    	
		this.path=new Path(String.valueOf(config.get(UniqConfig.YDB_PARSER_CLASS_PATH)),String.valueOf(readerIndex+prefix));
		this.refreshCheck=new RefreshCheck(scrollsecs);
		LOG.info("open outStreams "+Utils.pathToString(this.path)+","+this.isBackup);

    	
	}
	
	
	HdfsFileWriter outStreams=null;
	AtomicLong writeSizes=new AtomicLong(0);
	private long scrollSize=1024l*1024*1024;
	public synchronized void putdata(byte[] databytes) throws IOException
	{
		String message=new String(databytes,"utf-8");
		
		
		if(this.isBackup)
		{
			long cntnum=writeSizes.addAndGet(databytes.length);
			
			try{
				if(outStreams==null||this.refreshCheck.check()||cntnum>scrollSize)
				{
					writeSizes.set(0);
					this.refreshCheck.check();
					FileSystem fs=HadoopUtil.getFs(UniqConfig.INSTANCE().getConfCache());
	
					String yyyymmmdddhhmmss=DateFormatUtils.DateFormat.get_yyyyMMddHHmmss().format(new Date(System.currentTimeMillis()));
					String yyyymmmddd=DateFormatUtils.DateFormat.get_yyyyMMdd().format(new Date(System.currentTimeMillis()));
	
					Path finishpath=new Path(this.path,"finish");
					Path yyyymmddPath=new Path(finishpath,yyyymmmddd);
					fs.mkdirs(yyyymmddPath);
					Path writefile=new Path(yyyymmddPath,yyyymmmdddhhmmss+"_"+StormUtils.uuidLong())	;
					
					if(this.outStreams!=null)
					{
						this.closeStreams();
					}
					LOG.info("open outStreams "+Utils.pathToString(writefile));
	
				   	this.outStreams=new HdfsFileWriter(fs,writefile,UniqConfig.INSTANCE().BufferSizeWrite());	
				}

				StringBuffer buffer=new StringBuffer(message);
				buffer.append("\r\n");
			
				byte[] data=buffer.toString().getBytes("utf-8");
				this.outStreams.writeBytes(data,data.length);
			}catch(Throwable e)
			{
				LOG.error("writeBytes",e);
				this.closeStreams();

			}
		}
		
		
		try {
			messageQueue.put(message);
		} catch (Throwable e) {
		}
	
	}
	
	private void closeStreams()
	{
		try{
			this.outStreams.close();
			}catch(Throwable e)
			{
				LOG.error("outStreams",e);
			}
		finally{
			this.outStreams=null;
		}
	}

	@Override
	public List<Object> read() throws IOException {
		try {
			String message = messageQueue.poll(1,TimeUnit.SECONDS);
			if (message != null) {
				ArrayList<Object> rtn=new ArrayList<Object>(1);
				rtn.add(message);
				return rtn;
			}
		} catch (final Throwable e) {
			LOG.error("nextTuple failed for interrupt! ", e);
		} 
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
		
		}
		return new ArrayList<Object>(0);
	
	}

	@Override
	public void close() throws IOException {

		closeStreams();
	}


}
