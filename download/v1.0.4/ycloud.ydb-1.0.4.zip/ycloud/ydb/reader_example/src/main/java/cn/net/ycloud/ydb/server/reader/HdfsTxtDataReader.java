package cn.net.ycloud.ydb.server.reader;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import backtype.storm.utils.Utils;
import cn.net.ycloud.ydb.utils.HadoopUtil;
import cn.net.ycloud.ydb.utils.LogRate;
import cn.net.ycloud.ydb.utils.LogRatePool;
import cn.net.ycloud.ydb.utils.RefreshCheck;
import cn.net.ycloud.ydb.utils.UniqConfig;
import cn.net.ycloud.ydb.utils.AsyncGet.CachePool;
import cn.net.ycloud.ydb.utils.AsyncGet.SoftCachePool;
import cn.net.ydbmix.ydb.core.index.YdbDocValues;
import cn.net.ydbmix.ydb.core.index.YdbDocValues.Lazy;
import cn.net.ydbmix.ydb.time.DateFormatUtils;

public class HdfsTxtDataReader implements RawDataReader {
    private static final Log LOG = LogFactory.getLog(HdfsTxtDataReader.class.getName());
	private Path path;
	
	private LinkedBlockingDeque<Path> queue=new LinkedBlockingDeque<Path>();
	private AtomicLong totalReadCount=new AtomicLong(0);
	private AtomicLong lastHourCount=new AtomicLong(0);
	private AtomicLong lastts=new AtomicLong(System.currentTimeMillis());

	private BufferedReader CurrentInput=null;
	private RefreshCheck check=null;
	public RefreshCheck refreshCheck=null;
	public LogRate monitorLog=null;
	
	private Path currentFile=null;
	@Override
	public void init(String prefix,Map conf, int readerIndex, int readerCount)
			throws IOException {
		this.path=new Path(String.valueOf(conf.get(UniqConfig.YDB_PARSER_CLASS_PATH)),String.valueOf(readerIndex+prefix));
		this.check=new RefreshCheck(UniqConfig.INSTANCE().Reader_monitor_secs());
		this.refreshCheck=new RefreshCheck(3600);
		this.monitorLog=LogRatePool.get();
	}
	
	private void monitor() throws FileNotFoundException, IOException, InterruptedException
	{
		if(this.check.check())
		{
			if(refreshCheck.check())
			{
				lastHourCount.set(totalReadCount.get());
				totalReadCount.set(0);
			}
			
			LOG.info("monitor path:"+this.path+","+totalReadCount.get()+","+lastHourCount.get());
			ArrayList<String> sortresult=new ArrayList<String>();
			FileSystem fs=HadoopUtil.getFs(UniqConfig.INSTANCE().getConfCache());
			Path listpath=this.path;
			if(fs.exists(listpath))
			{
				FileStatus[] list=fs.listStatus(listpath);
				Arrays.sort(list,Utils.ComparatorFileStatusAsc());
				
				for (FileStatus s : list) {
					if(s.isFile())
					{
						queue.put(s.getPath());
						
						try{
							Date d=new Date(Utils.getModificationTime(s));
						sortresult.add(s.getPath().getName()+"="+DateFormatUtils.DateFormat.get_yyyy_MM_dd_HH_mm_ss().format(d));
						}catch(Throwable e){};
					}
				}
				
				LOG.info("monitor files list:"+this.path+"\t"+sortresult+","+totalReadCount.get()+","+lastHourCount.get());

			}
		}else{
			if(monitorLog.allowlog())
			{
				LOG.info("monitor path need wait:"+this.path+","+totalReadCount.get()+","+lastHourCount.get());
			}
			
			this.sleep(30);
		}
	}
	
	
	   
    private void sleep(int i)
    {
    	try {
			Thread.sleep(i);
		} catch (InterruptedException e1) {
		}
    }
	
	public void nextInput() throws FileNotFoundException, IOException, InterruptedException
	{
		this.closeInput(true);
	
		
		Path p=this.queue.poll();
		if(p==null)
		{
			this.monitor();
		}
		
		if(p==null)
		{
			return ;
		}
		
		this.currentFile=p;
		LOG.info("nextInput file:"+p.toString()+","+totalReadCount.get()+","+lastHourCount.get()+","+(System.currentTimeMillis()-lastts.get()));

		lastts.set(System.currentTimeMillis());
		FileSystem fs=HadoopUtil.getFs(UniqConfig.INSTANCE().getConfCache());
		this.CurrentInput = new BufferedReader(new InputStreamReader(fs.open(p), "UTF-8"),UniqConfig.INSTANCE().ydbBuffer());  
	}

	@Override
	public List<Object> read() throws IOException {
		List<Object> rtn=new ArrayList<Object>(1);
		try{
			if(CurrentInput!=null)
			{
				String line=CurrentInput.readLine();
				if(line!=null)
				{
					totalReadCount.incrementAndGet();
					rtn.add(line);
					return rtn;
				}
			}
		}catch(Throwable e)
		{
			LOG.info("read error",e);
		}
		
		try {
			this.nextInput();
		} catch (InterruptedException e) {
			LOG.info("read nextInput error ",e);

		}
		return rtn;
	}
	
	
	public void closeInput(boolean ismove) throws IOException
	{

		if(CurrentInput!=null)
		{
			try{
			CurrentInput.close();
			}catch(Throwable e)
			{
				LOG.info("close error",e);
			}
			CurrentInput=null;
		}
		
		
		if(ismove)
		{
			FileSystem fs=HadoopUtil.getFs(UniqConfig.INSTANCE().getConfCache());
			if(this.currentFile!=null)
			{
				String yyyymmmdddhhmmss=DateFormatUtils.DateFormat.get_yyyyMMddHHmmss().format(new Date(System.currentTimeMillis()));
				String yyyymmmddd=DateFormatUtils.DateFormat.get_yyyyMMdd().format(new Date(System.currentTimeMillis()));

				Path finishpath=new Path(this.currentFile.getParent(),"finish");
				Path yyyymmddPath=new Path(finishpath,yyyymmmddd);
				fs.mkdirs(yyyymmddPath);
				fs.rename(this.currentFile, new Path(yyyymmddPath,this.currentFile.getName()+"_"+yyyymmmdddhhmmss));
			}	
		}
	
	}

	@Override
	public void close() throws IOException {
		this.closeInput(false);
	}

}
