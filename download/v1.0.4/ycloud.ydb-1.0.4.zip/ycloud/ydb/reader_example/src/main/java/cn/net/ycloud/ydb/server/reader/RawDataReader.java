package cn.net.ycloud.ydb.server.reader;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public interface  RawDataReader
 {
	public void init(String prefix,Map config, int readerIndex, int readerCount)
			throws IOException;
	public List<Object> read() throws IOException;
	public void close() throws IOException;
}