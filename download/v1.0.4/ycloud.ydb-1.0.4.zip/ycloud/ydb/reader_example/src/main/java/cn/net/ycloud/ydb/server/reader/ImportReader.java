package cn.net.ycloud.ydb.server.reader;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import cn.net.ycloud.ydb.utils.LogRate;
import cn.net.ycloud.ydb.utils.LogRatePool;
import cn.net.ycloud.ydb.utils.StringUtils;
import cn.net.ycloud.ydb.utils.UniqConfig;




public class ImportReader
{
    private static final Log LOG = LogFactory.getLog(ImportReader.class.getName());
    private final static int NEW_ENTRIES_COUNT = 20;
    private RawDataReader rawDataReader;
    private Parser parser;

    public ImportReader(String prefix,Map conf, int readerIndex, int readerCount)
	throws IOException
    {
		try {
			
			rawDataReader=(RawDataReader) Class.forName(String.valueOf(conf.get(UniqConfig.YDB_READER_CLASS_KEY+prefix))).newInstance();
			LOG.info("ydb.reader.read.class:"+rawDataReader.getClass().getName());
			rawDataReader.init(prefix,conf, readerIndex, readerCount);
			
		    this.parser = (Parser) Class.forName(String.valueOf(conf.get(UniqConfig.YDB_PARSER_CLASS_KEY+prefix))).newInstance();;
			LOG.info("ydb.reader.parser.class:"+this.parser.getClass().getName());
			parser.init(prefix,conf, readerIndex, readerCount);
		} catch (Throwable e1) {
			LOG.error("RawDataReader",e1);
		}
    }
    
    public void close() throws IOException
    {
    	this.rawDataReader.close();
    }


	public synchronized List<YdbParse> read() throws IOException {
		List<Object> rawData = rawDataReader.read();
		List<YdbParse> entries = new ArrayList<YdbParse>(NEW_ENTRIES_COUNT);
		if (rawData != null&&rawData.size()>0) {
			for (Object str : rawData) {

				try {
					printlog(str);
					YdbParse e = parser.parse(str);
					if(e!=null)
					{
						entries.add(e);
					}else{
						debugError(str,null);
					}
				} catch (Throwable iee) {
					debugError(str,iee);
				}
			}
		}

		return entries;
	}


	private static LogRate logIntervelNormal=LogRatePool.get();
	
	private static LogRate logIntervelError=LogRatePool.get();
	
	public void printlog(Object s) {
		
		if(logIntervelNormal.allowlog())
		{
			if(s!=null&&s.getClass().isArray())
			{
				LOG.info(StringUtils.cutForLog(Arrays.toString((Object[])s)));

			}else{
				LOG.info(StringUtils.cutForLog(String.valueOf(s)));
			}
		}
		
	}
	
		

	public void debugError(Object s,Throwable e) {
		if(logIntervelError.allowlog())
		{
			if(e!=null)
			{
				if(s!=null&&s.getClass().isArray())
				{
					LOG.error(StringUtils.cutForLog(Arrays.toString((Object[])s)),e);

				}else{
					LOG.error(StringUtils.cutForLog(String.valueOf(s)),e);
				}

			}else{
				if(s!=null&&s.getClass().isArray())
				{
					LOG.error(StringUtils.cutForLog(Arrays.toString((Object[])s)));

				}else{
					LOG.error(StringUtils.cutForLog(String.valueOf(s)));
				}
			}
		}
	}


}


