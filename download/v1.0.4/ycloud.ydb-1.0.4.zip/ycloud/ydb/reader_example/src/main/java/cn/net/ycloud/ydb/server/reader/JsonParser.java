package cn.net.ycloud.ydb.server.reader;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import cn.net.ycloud.ydb.json.JSONArray;
import cn.net.ycloud.ydb.json.JSONException;
import cn.net.ycloud.ydb.json.JSONObject;
import cn.net.ycloud.ydb.utils.LogRate;
import cn.net.ycloud.ydb.utils.LogRatePool;

public class JsonParser implements Parser{
    private static final Log LOG = LogFactory.getLog(JsonParser.class.getName());

	@Override
	public void init(String prefix,Map config, int readerIndex, int readerCount)
			throws IOException {
		
	}
	
	public static void main(String[] args) {
		String line=String.valueOf("sdd{1");
		if(!line.startsWith("{"))
		{
			int indexof=line.indexOf("{");
			if(indexof>0)
			{
				line=line.substring(indexof);
			}
		}
		System.out.println(line);
	}

	private static LogRate logIntervelNormal=LogRatePool.get();
	private static LogRate logIntervelNotJson=LogRatePool.get();


	@Override
	public YdbParse parse(Object raw) throws Throwable {
		try{
			String line=String.valueOf(raw);
			if(!line.startsWith("{"))
			{
				int indexof=line.indexOf("{");
				if(indexof>0)
				{
					line=line.substring(indexof);
				}
			}
			if(line.startsWith("{"))
			{
				JSONObject colsJson=new JSONObject(line);
				String tablename= colsJson.getString("tablename");
				 
				String ydbpartion=colsJson.getString("ydbpartion");
				
				ArrayList<YdbParseItem> list=new ArrayList<YdbParseItem>(8); 
				
				if(colsJson.has("cleanMatch")||colsJson.has("addIndex"))
				{
					Map<String,String> addIndex=null;
					List<String> cleanMatch=null;
					if(colsJson.has("cleanMatch"))
					{
						JSONArray datalist=colsJson.getJSONArray("cleanMatch");
						cleanMatch=new ArrayList<String>();
						int len=datalist.length();
						for(int i=0;i<len;i++)
						{
							cleanMatch.add(datalist.getString(i));
						}

					}
					
					if(colsJson.has("addIndex"))
					{
						JSONObject data=colsJson.getJSONObject("addIndex");
						addIndex=new HashMap<String, String>(); 
						for  (Iterator iter = data.keys(); iter.hasNext();) { 
					    	String field = (String)iter.next();
					    	addIndex.put(field, data.getString(field));
						}

					}
					
					YdbParseItem item=new YdbParseItem(addIndex,cleanMatch ,tablename,ydbpartion, line.length());
					list.add(item);

				}
				
				
				if(colsJson.has("list"))
				{
					JSONArray datalist=colsJson.getJSONArray("list");
					int len=datalist.length();
					for(int i=0;i<len;i++)
					{
						JSONObject data=datalist.getJSONObject(i);
						HashMap<String, Object> cols=new HashMap<String, Object>(); 
						for  (Iterator iter = data.keys(); iter.hasNext();) { 
					    	String field = (String)iter.next();
							cols.put(field, data.getString(field));
						}
						
						YdbParseItem item=new YdbParseItem(cols,tablename,ydbpartion, (line.length()/len));
						list.add(item);
					}
				}
				
				if(colsJson.has("data"))
				{
					JSONObject data=colsJson.getJSONObject("data");
	
					HashMap<String, Object> cols=new HashMap<String, Object>(); 
					for  (Iterator iter = data.keys(); iter.hasNext();) { 
				    	String field = (String)iter.next();
						cols.put(field, data.getString(field));
					}
					
					YdbParseItem item=new YdbParseItem(cols ,tablename,ydbpartion, line.length());
					list.add(item);

				}
				
				return new YdbParse(true,list.toArray(new YdbParseItem[list.size()]));
			}else{
				if(logIntervelNotJson.allowlog())
				{
					LOG.info("not json so skip "+line);
				}	
			}
			

		}catch(JSONException e)
		{
			if(logIntervelNormal.allowlog())
			{
				LOG.error("parse error",e);
			}
		}
		
		return new YdbParse(false, new YdbParseItem[0]);
	}

}
