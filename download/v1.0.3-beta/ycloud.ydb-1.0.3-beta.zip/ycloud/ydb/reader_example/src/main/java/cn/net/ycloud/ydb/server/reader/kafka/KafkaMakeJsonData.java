package cn.net.ycloud.ydb.server.reader.kafka;
import java.util.Properties;
import java.util.Random;

import cn.net.ycloud.ydb.json.JSONException;
import cn.net.ycloud.ydb.json.JSONObject;
import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;
public class KafkaMakeJsonData {
	 public static void main(String[] args) throws JSONException {
	        Random rnd = new Random();
	 
	        Properties props = new Properties();
	        String topic="ydbtest";
	        props.put("metadata.broker.list", "192.168.112.129:9092");
	        props.put("serializer.class", "kafka.serializer.StringEncoder");
	        props.put("partitioner.class", SimplePartitioner.class.getName());
	        props.put("request.required.acks", "1");
	 
	        ProducerConfig config = new ProducerConfig(props);
	 
	        Producer<String, String> producer = new Producer<String, String>(config);
	 

			for(int i=0;i<=0;i++)
			{
				
				double sumuserage=0;
				double clickcount=0;
				double paymoney=0;
				double price=0;

				for(int j=0;j<2500;j++)
				{
					
					JSONObject json=new JSONObject();
					JSONObject data=new JSONObject();
					sumuserage+=j%30+10;
					clickcount+=j%60;
					paymoney+=j%60+j*0.033;
					price+=j%30+j*0.03;

					
					data.put("indexnum", j);

					data.put("label", "l_"+j%30);
					data.put("userage", j%30+10);
					data.put("clickcount", j%60);
					data.put("paymoney", j%60+j*0.033);
					data.put("price", j%30+j*0.03);

					data.put("content", j%15+" "+j%18+" "+j%14 +" 延云 ydb 延云  测试  中文分词 中华人民共和国 沈阳延云云计算技术有限公司");

					data.put("contentcjk", j%15+" "+j%18+" "+j%14 +" 延云 ydb 延云  测试  中文分词 中华人民共和国 沈阳延云云计算技术有限公司");

					
					json.put("tablename", "ydbexample");
					json.put("ydbpartion", "20151208");
					json.put("data", data);

					 
		               String msg =json.toString(); 
		               KeyedMessage<String, String> kafkadata = new KeyedMessage<String, String>(topic, String.valueOf(rnd.nextInt(255)), msg);
		               producer.send(kafkadata);
		               System.out.println(msg);
		        
					System.out.println();
				}
				
				System.out.println("sumuserage="+sumuserage);
				System.out.println("clickcount="+clickcount);
				System.out.println("paymoney="+paymoney);
				System.out.println("price="+price);

			}
		
	        
	        
       producer.close();
	    }
}
