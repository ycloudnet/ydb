package cn.net.ycloud.ydb.server.reader.kafka;

import java.io.UnsupportedEncodingException;
import java.util.concurrent.LinkedBlockingQueue;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import kafka.consumer.ConsumerIterator;
import kafka.consumer.KafkaStream;
 
public class ConsumerRunable implements Runnable {
    private static final Log LOG = LogFactory.getLog(ConsumerRunable.class.getName());

    private KafkaStream m_stream;
    private int m_threadNumber;
    private KafkaDataReader messageQueue=null;
    public ConsumerRunable(KafkaDataReader messageQueue,KafkaStream a_stream, int a_threadNumber) {
        m_threadNumber = a_threadNumber;
        m_stream = a_stream;
        this.messageQueue=messageQueue;
    }
 
    public void run() {
    	LOG.info("run Thread: " + m_threadNumber);

        ConsumerIterator<byte[], byte[]> it = m_stream.iterator();
        while (it.hasNext())
        {
        	try {
        		messageQueue.putdata(it.next().message());
			} catch (Throwable e) {
			}
        }
        LOG.info("Shutting down Thread: " + m_threadNumber);
    }
}