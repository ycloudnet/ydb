package cn.net.ycloud.ydb.server.reader.kafka;
import java.util.Random;

import cn.net.ycloud.ydb.json.JSONException;
import cn.net.ycloud.ydb.json.JSONObject;

/**
 * 
 * 
create table ydb_example_rank(
rank string,
domain string,
landingPage string,
subRankParams string,
label string,
subRankVOs string,
rating string,
type string
)



 * 
 * @author yannianmu
 *
 */
public class MakeJsonData2Hdfs2 {

	// {"knogTag":"","keyword":"%E4%B8%89%E7%9B%B8%E6%AD%A5%E8%BF%9B%E7%94%B5%E6%9C%BA%E9%A9%B1%E5%8A%A8%E5%99%A8","queryDate":"2015-12-14","qeuryState":100,"firstPageSize":10,"plaFlg":"N","ppcFlg":"N","llFlg":"N","keywordRankEntityVOs":[{"rank":1,"landingPage":"http://baike.baidu.com/view/13608.htm","label":"步进电机_百度百科","rating":"","subRankVOs":[],"type":1},{"rank":2,"landingPage":"http://www.moons.com.cn/product/motor_drive/Drive_Motor/ST/3Phase/","label":"ST三相步进电机驱动控制器- 上海鸣志","rating":"","subRankVOs":[],"type":1},{"rank":3,"landingPage":"http://www.moons.com.cn/product/motor_drive/Download/Product_Manual/201501/W020150514371961251993.pdf","label":"三相步进电机驱动器 - 鸣志","rating":"","subRankVOs":[],"type":1},{"rank":4,"landingPage":"http://www.yankong.com/docc/product/default2_15_1.html","label":"产品中心_步进电机驱动器/两相步进电机驱动器/三相步进电机 ...","rating":"","subRankVOs":[],"type":1},{"rank":5,"landingPage":"http://www.baike.com/wiki/%E6%AD%A5%E8%BF%9B%E7%94%B5%E6%9C%BA","label":"步进电机_互动百科","rating":"","subRankVOs":[],"type":1},{"rank":6,"landingPage":"http://www.motorzj.com/drive.htm","label":"三相细分混合式步进电机驱动器","rating":"","subRankVOs":[],"type":1},{"rank":7,"landingPage":"http://www.rubbur.cn/products/products-list.aspx?id\u003d589","label":"三相交流式步进电机驱动器RB3722 - 步进电机,步进电机 ...","rating":"","subRankVOs":[],"type":1},{"rank":8,"landingPage":"http://www.rubbur.cn/products/products-list.aspx?id\u003d592","label":"三相混合式步进电机驱动器RB368 - 步进电机,步进电机驱动器 ...","rating":"","subRankVOs":[],"type":1},{"rank":9,"landingPage":"http://www.sihongmotor.com/products-detail.asp?cpid\u003d26","label":"SH-30806三相步进电机驱动器","rating":"","subRankVOs":[],"type":1},{"rank":10,"landingPage":"http://www.sdcq-micromotor.com/Product.aspx?id\u003d29","label":"三相步进电机驱动器ZD-3HD660-北京时代超群电器科技有限 ...","rating":"","subRankVOs":[],"type":1},{"rank":11,"landingPage":"http://www.beckhoff.com.cn/cn/Document/motion%20and%20control/stepmotorQA.pdf","label":"步进电机技术十四问","rating":"","subRankVOs":[],"type":1},{"rank":12,"landingPage":"http://www.360doc.com/content/12/0503/05/8732507_208259814.shtml","label":"三相反应式步进电动机的工作原理及驱动方法","rating":"","subRankVOs":[],"type":1},{"rank":13,"landingPage":"http://www.jss-motor.cn/","label":"常州金三士是制造三相步进电机、二相步进电机、两相混合式 ...","rating":"","subRankVOs":[],"type":1},{"rank":14,"landingPage":"http://leisai.com/product/detail.aspx?id\u003d153\u0026nodecode\u003d101030\u0026ArrayParentID\u003d0,1\u0026ParentID\u003d1\u0026PinID\u003d15","label":"110系列三相混合式步进电机步进电机","rating":"","subRankVOs":[],"type":1},{"rank":15,"landingPage":"http://www.cmosic.com/index.php/products_v_50_57.html","label":"三相步进电机驱动器 - 深圳市微芯集成电路设计有限公司","rating":"","subRankVOs":[],"type":1},{"rank":16,"landingPage":"http://read.pudn.com/downloads166/ebook/759783/%E4%B8%89%E7%9B%B8%E6%AD%A5%E8%BF%9B%E7%94%B5%E6%9C%BA%E9%A9%B1%E5%8A%A8%E5%99%A8%E8%AE%BE%E8%AE%A1.PDF","label":"种实用的三相步进电机驱动器的设计 - Read","rating":"","subRankVOs":[],"type":1},{"rank":17,"landingPage":"http://www.ti.com.cn/tool/cn/TIDM-THREEPHASE-BSDC","label":"三相刷式和步进电机控制解决方案- TIDM-THREEPHASE ...","rating":"","subRankVOs":[],"type":1},{"rank":18,"landingPage":"http://www.eepw.com.cn/article/73889.htm","label":"步进电动机的工作原理及驱动方法 - EEPW 电子产品世界","rating":"","subRankVOs":[],"type":1},{"rank":19,"landingPage":"http://www.jiyomotor.com/products/bujindianjiqudongqi/sanxiangAC110-220Vbu/list-137-1.html","label":"三相AC110-220V步进驱动器-步进电机驱动器","rating":"","subRankVOs":[],"type":1},{"rank":20,"landingPage":"http://www.bsjd.com/","label":"深圳白山机电: 自主研发、生产、销售步进电机驱动器厂家-","rating":"","subRankVOs":[],"type":1},{"rank":21,"landingPage":"http://ftp.ruigongye.com/200808/baigela.doc","label":"百格拉三相混合式步进电机及驱动器","rating":"","subRankVOs":[],"type":1},{"rank":22,"landingPage":"http://www.stepping.cn/","label":"步进电机驱动器,步进电机控制器,闭环步进,无刷风机驱动器 ...","rating":"","subRankVOs":[],"type":1},{"rank":23,"landingPage":"http://www.sckjmotor.com/","label":"深圳双成科技","rating":"","subRankVOs":[],"type":1},{"rank":24,"landingPage":"http://www.scs-college.com/%E4%B8%89%E7%9B%B8%E6%AD%A5%E8%BF%9B%E7%94%B5%E6%9C%BA%E9%A9%B1%E5%8A%A8%E5%99%A8/","label":"三相步进电机驱动器展示_接线图分享","rating":"","subRankVOs":[],"type":1},{"rank":25,"landingPage":"http://www.yrmcu.com/pictures/chinfo/files/HM380A%E4%B8%89%E7%9B%B8%E6%B7%B7%E5%90%88%E5%BC%8F%E5%8F%AF%E5%8F%98%E7%BB%86%E5%88%86%E6%AD%A5%E8%BF%9B%E7%94%B5%E6%9C%BA%E9%A9%B1%E5%8A%A8%E5%99%A8.pdf","label":"HM380A三相混合式可变细分步进电机驱动器","rating":"","subRankVOs":[],"type":1},{"rank":26,"landingPage":"http://www.gldmotor.com/Products/Search.php?cateId\u003d14","label":"三相步进电机驱动器—北京嘉蓝德科技有限公司","rating":"","subRankVOs":[],"type":1},{"rank":27,"landingPage":"http://ai.taobao.com/cp/ubYjuuDFuSJvrb8muuaNuexrr4tduAS_uOt_.html","label":"三相步进电机驱动器 - 淘宝网","rating":"","subRankVOs":[],"type":1},{"rank":28,"landingPage":"http://ican-tech.com.w.114my.com/product/detail/109.html","label":"3MR8，三相步进电机驱动器，步进电机驱动器","rating":"","subRankVOs":[],"type":1},{"rank":29,"landingPage":"http://www.google.com/patents/CN202026272U?cl\u003dzh","label":"Patent CN202026272U - 三相步进电机驱动器- Google Patents","rating":"","subRankVOs":[],"type":1},{"rank":30,"landingPage":"http://www.zjyuhai.cn/showprod.php?id\u003d84","label":"三相步进驱动器YH-3722 - 产品详情- 温岭市宇海机电有限公司","rating":"","subRankVOs":[],"type":1},{"rank":31,"landingPage":"http://www.sumtorelec.com/uploadfiles/2013128/2013128115747536.pdf","label":"3M2080 三相高压步进电机驱动器","rating":"","subRankVOs":[],"type":1},{"rank":32,"landingPage":"http://www.leetro.com/product-8.html","label":"驱动产品","rating":"","subRankVOs":[],"type":1},{"rank":33,"landingPage":"http://www.dzkf.cn/html/zonghejishu/2008/0320/3048.html","label":"一种实用的三相步进电机驱动器的设计-电子开发网","rating":"","subRankVOs":[],"type":1},{"rank":34,"landingPage":"http://www.zscnc.cn/Product/293017156.html","label":"86系列三相步进电机-杭州之山智控技术有限公司","rating":"","subRankVOs":[],"type":1},{"rank":35,"landingPage":"http://www.chinabaike.com/m/s/1405487.html","label":"三相步进电机工作原理_中国百科网","rating":"","subRankVOs":[],"type":1},{"rank":36,"landingPage":"http://www.bohongmotor.com/product/BH-3P860%E4%B8%89%E7%9B%B8%E6%AD%A5%E8%BF%9B%E7%94%B5%E6%9C%BA%E9%A9%B1%E5%8A%A8%E5%99%A8_3941.html","label":"86BYG350步进电机驱动器,三相步进电机驱动器 - 步进伺服电机","rating":"","subRankVOs":[],"type":1},{"rank":37,"landingPage":"http://www.likomotor.com/_default_v48.aspx","label":"LK-2024两相步进电机驱动器 - 常州市丽控机电有限公司官网","rating":"","subRankVOs":[],"type":1},{"rank":38,"landingPage":"http://www.samsrmotor.com.cn/detail.aspx?cid\u003d399","label":"三相混合式步进电机及驱动器电流细分驱动- 山社电机--步进 ...","rating":"","subRankVOs":[],"type":1},{"rank":39,"landingPage":"http://ia.newmaker.com/pro_13860.html","label":"MD系列三相步进电机驱动器- 佳工网","rating":"","subRankVOs":[],"type":1},{"rank":40,"landingPage":"http://leisai.cn.china.cn/supply/1562808353.html","label":"供应雷赛3相步进电机驱动器3DM683 - 深圳雷赛科技有限公司","rating":"","subRankVOs":[],"type":1},{"rank":41,"landingPage":"http://www.jshstdj.com/products-detail.asp?cpid\u003d220","label":"57-86混合式三相步进电机驱动器","rating":"","subRankVOs":[],"type":1},{"rank":42,"landingPage":"http://www.ican-tech.com/product/category/57/1/12.html","label":"静音型三相步进电机系列 - 步进电机驱动器","rating":"","subRankVOs":[],"type":1},{"rank":43,"landingPage":"http://bukemotor.com/product1.asp?tyc\u003d2012727100919\u0026tt\u003d2012727100919","label":"三相步进电机驱动器-乐清市步科电机有限公司","rating":"","subRankVOs":[],"type":1},{"rank":44,"landingPage":"http://www.freedocuments.info/7341305107/","label":"基于反激式电源的三相步进电机驱动器设计.Stamped - 免费 ...","rating":"","subRankVOs":[],"type":1},{"rank":45,"landingPage":"http://www.21xia.cn/sell/show-36683.html","label":"RB-3722 三相步进电机驱动器 - B2B电子商务网站","rating":"","subRankVOs":[],"type":1},{"rank":46,"landingPage":"https://www.1688.com/chanpin/-B2BDBDF8B5E7BBFAC7FDB6AFC6F7.html","label":"步进电机驱动器 - 阿里巴巴","rating":"","subRankVOs":[],"type":1},{"rank":47,"landingPage":"http://db22.com/kongzhiqi/2.html","label":"3MD605三相步进电机驱动器","rating":"","subRankVOs":[],"type":1},{"rank":48,"landingPage":"http://www.startsh.com/cnc/tags/?/%B2%BD%BD%F8%B5%E7%BB%FA/","label":"步进电机 - 斯达特","rating":"","subRankVOs":[],"type":1},{"rank":49,"landingPage":"http://www.bjzdkz.com/UploadFiles/20079518334503.doc","label":"三相混合式步进电机驱动器B3C的工作原理 - 无锡市步进自动 ...","rating":"","subRankVOs":[],"type":1},{"rank":50,"landingPage":"http://www.hy-smd.com/","label":"五相步进电机,五相步进电机驱动器,三相步进电机及驱动器","rating":"","subRankVOs":[],"type":1},{"rank":51,"landingPage":"http://www.tpy.cn/UploadFile/201337154839138.pdf","label":"三相反应式步进电机驱动器的设计","rating":"","subRankVOs":[],"type":1},{"rank":52,"landingPage":"http://www.kaifull.net/Stepper-Motor/3-Phase-DC/","label":"三相直流步进电机|马达—凯福机电有限公司","rating":"","subRankVOs":[],"type":1},{"rank":53,"landingPage":"http://www.pw0.cn/article/dgjs/2014/1218/35840.html","label":"两相步进电机驱动器接线示意图- 电工技术- 电工之家","rating":"","subRankVOs":[],"type":1},{"rank":54,"landingPage":"http://www.inasmotion.com/","label":"步进电机|步进驱动器|伺服电机,驱动器专业生产商--英纳仕智能","rating":"","subRankVOs":[],"type":1},{"rank":55,"landingPage":"http://www.fd-motor.com/","label":"三相混合式步进电机_交流伺服电机驱动器_伺服电机驱动器_ ...","rating":"","subRankVOs":[],"type":1},{"rank":56,"landingPage":"http://www.kangdejishu.com/prodetail/285725.aspx","label":"三相步进电机驱动器价格_型号_参数_规格- 高压变频器-河北 ...","rating":"","subRankVOs":[],"type":1},{"rank":57,"landingPage":"http://www.gkong.com/infobbs/ib_content.asp?id\u003d168799","label":"供应YAKO两相/三相步进电机驱动器- 深圳市研控自动化科技 ...","rating":"","subRankVOs":[],"type":1},{"rank":58,"landingPage":"http://blog.chinaunix.net/uid-29767373-id-4498214.html","label":"什么是三相步进电机驱动器？-对着月亮说太阳-ChinaUnix博客","rating":"","subRankVOs":[],"type":1},{"rank":59,"landingPage":"http://www.tc55.cn/product/11012626087.html","label":"TOPCNC 三相步进驱动器TC8635 4.8A 86电机110电机- 套装 ...","rating":"","subRankVOs":[],"type":1},{"rank":60,"landingPage":"http://www.cndxe.com/Product.asp?Action\u003dView\u0026ProductID\u003d124\u0026Catalog\u003d40","label":"三相细分型步进电机驱动器","rating":"","subRankVOs":[],"type":1},{"rank":61,"landingPage":"http://www.lingsaimotor.com/offerlist/62127345.htm","label":"三相步进电机驱动器产品展示东莞菱赛机电有限公司官网","rating":"","subRankVOs":[],"type":1},{"rank":62,"landingPage":"http://www.motion-con.com/news_detail/\u0026i\u003d44\u0026comContentId\u003d44.html","label":"珠海运控发布全新无位置传感器三相电机驱动器,珠海运控电机 ...","rating":"","subRankVOs":[],"type":1},{"rank":63,"landingPage":"http://www.yongkun-motor.com/article.php?name\u003d2015091722","label":"步进电机简要说明及安装注意项,步进电机- 佛山市南海永坤 ...","rating":"","subRankVOs":[],"type":1},{"rank":64,"landingPage":"http://www.p-risedriver.com/product/showproduct.php?lang\u003dcn\u0026id\u003d46","label":"57系列三相步进电机","rating":"","subRankVOs":[],"type":1},{"rank":65,"landingPage":"http://www.upuru.com/?cat\u003d8","label":"三相步进电机驱动器","rating":"","subRankVOs":[],"type":1},{"rank":66,"landingPage":"https://zh.wikipedia.org/zh-cn/%E6%AD%A5%E9%80%B2%E9%A6%AC%E9%81%94","label":"步進馬達- 维基百科，自由的百科全书","rating":"","subRankVOs":[],"type":1},{"rank":67,"landingPage":"http://www.hamderburg.com/Article3.aspx?ColumnId\u003d73\u0026ArticleId\u003d1086\u0026Language\u003d34\u0026Terminal\u003d41","label":"步进电机细分特点- 汉德保(HDB)电机 - 汉德保电机","rating":"","subRankVOs":[],"type":1},{"rank":68,"landingPage":"http://www.szmyck.com/","label":"五相步进电机、步进电机驱动器、步进电机-深圳市明远测控 ...","rating":"","subRankVOs":[],"type":1},{"rank":69,"landingPage":"http://www.servo123.com/news/?39_535.html","label":"F3722三相步进电机驱动器说明书 - 步进驱动器_步进电机批发","rating":"","subRankVOs":[],"type":1},{"rank":70,"landingPage":"http://utmotor.com/product/p-0-10.html","label":"三相混合式步进电机驱动器-广州佑田机械设备有限公司","rating":"","subRankVOs":[],"type":1},{"rank":71,"landingPage":"http://www.xmsian.com/index.php/yka3722-three-phase-stepping-motor-driver/","label":"YKA3722三相步进电机驱动器| 厦门鑫思安机电有限公司","rating":"","subRankVOs":[],"type":1},{"rank":72,"landingPage":"http://public.hbut.edu.cn/tsme/gerenwww/jdcdykz/data/UploadFile/ckzl/%E4%B8%89%E7%9B%B8%E6%AD%A5%E8%BF%9B%E7%94%B5%E6%9C%BA%E9%A9%B1%E5%8A%A8%E5%99%A8%E4%BA%A7%E5%93%81%E6%89%8B%E5%86%8C.pdf","label":"三相步进电机驱动器产品手册","rating":"","subRankVOs":[],"type":1},{"rank":73,"landingPage":"http://www.hymcu.com/ProductShow.asp?ArticleID\u003d259","label":"三相步进电机驱动器(AC220V,7A) 3M3722 三相130步进电机 ...","rating":"","subRankVOs":[],"type":1},{"rank":74,"landingPage":"http://www.sz9xy.com/Cn/Product.aspx?CorpProductClass1_ID\u003d108736\u0026CorpProductClass2_ID\u003d132814\u0026UserInfo_ID\u003d823934","label":"三相步进电机_山社步进电机_步进电机_驱动器_山洋电机_山 ...","rating":"","subRankVOs":[],"type":1},{"rank":75,"landingPage":"http://www.schwrc.com/goods_41822051185.html","label":"三相步进电机驱动器(AC220V,7A) DV3722 三相130步进电机 ...","rating":"","subRankVOs":[],"type":1},{"rank":76,"landingPage":"http://samsrmotor.lofter.com/post/1cc67624_3dfaeb0","label":"MOONS两相/三相全细分驱动器适配山社步进电机总汇-山社 ...","rating":"","subRankVOs":[],"type":1},{"rank":77,"landingPage":"http://www.ydake.com/Cn/Product_Detail.aspx?UserInfo_ID\u003d753126\u0026CorpProductClass1_ID\u003d60585\u0026id\u003d747375","label":"130系列三相步进电机_产品展示_步进驱动器_步进电机 ...","rating":"","subRankVOs":[],"type":1},{"rank":78,"landingPage":"http://blog.tianya.cn/post-4474232-45975518-1.shtml","label":"三相步进电机驱动器3ND583_雷赛步进电机驱动器_天涯博客","rating":"","subRankVOs":[],"type":1},{"rank":79,"landingPage":"http://www.sikesai.com/product/stepperDrive/Three/","label":"三相步进电机驱动器_杭州步科机电有限公司","rating":"","subRankVOs":[],"type":1},{"rank":80,"landingPage":"http://www.top-cnc.com/index.php/download/load/33.html","label":"TC8637H 三相混合式步进电机驱动器说明书 - 北京多普康 ...","rating":"","subRankVOs":[],"type":1},{"rank":81,"landingPage":"http://szjb.b2b.csc86.com/product/171223.html","label":"DQ356M三相步进电机驱动器-其他分类尽在华南城网B2B ...","rating":"","subRankVOs":[],"type":1},{"rank":82,"landingPage":"http://www.dt-me.com/UploadFiles/DT3M8080.pdf","label":"DT3M8080 3相步进电机驱动器深圳市鼎拓达机电有限公司","rating":"","subRankVOs":[],"type":1},{"rank":83,"landingPage":"http://www.chinajingbo.com/","label":"步进电机_伺服电机","rating":"","subRankVOs":[],"type":1},{"rank":84,"landingPage":"http://www.xfoyo.com/bjdj/","label":"产品/ 步进电机及驱动器—深圳市兴丰元机电有限公司","rating":"","subRankVOs":[],"type":1},{"rank":85,"landingPage":"http://www.ucmotor.com/zh/goods/sxbujdji/","label":"三相步进电机 - 深圳优势机电有限公司专业经营各种电机,优势 ...","rating":"","subRankVOs":[],"type":1},{"rank":86,"landingPage":"http://www.hcrobot.com.cn/case.asp?lb_id\u003d8","label":"和利时三相步进电机驱动 - 汇创智控技术","rating":"","subRankVOs":[],"type":1},{"rank":87,"landingPage":"http://www.nc-tech.cc/ShopMore.asp?id\u003d29","label":"步进电机,步进电机驱动器,伺服电机驱动器,宁波纳川自动化 ...","rating":"","subRankVOs":[],"type":1},{"rank":88,"landingPage":"http://www.mianfeiwendang.com/doc/261c6d63073be88d5cf8f9fe","label":"基于STM32、IPM模块的三相步进电机SVPWM驱动器 - 免费文档","rating":"","subRankVOs":[],"type":1},{"rank":89,"landingPage":"http://61.146.118.6:8080/portal/blob?key\u003d6688387","label":"基于CPLD 的五相步进电机驱动器设计","rating":"","subRankVOs":[],"type":1},{"rank":90,"landingPage":"http://www.sitaipu.com/jjfa/2013/0220/96.html","label":"57三相步进电机_步进电机|直流无刷电机|步进电机驱动器|步 ...","rating":"","subRankVOs":[],"type":1},{"rank":91,"landingPage":"http://www.actrlrun.com/krxic-SonList-245454/","label":"步进电机驱动器-北京科日新控电子技术有限公司","rating":"","subRankVOs":[],"type":1},{"rank":92,"landingPage":"http://www.cw-motor.com/index.php?m\u003dcontent\u0026c\u003dindex\u0026f\u003dshow\u0026catid\u003d164\u0026l\u003d1\u0026id\u003d65","label":"步进电机入门与误区[产品百科]-常州创伟电机电器有限公司","rating":"","subRankVOs":[],"type":1},{"rank":93,"landingPage":"http://www.syn-tron.com/download/cataloge/stepdriver/SD31007.pdf","label":"特点性能指标数字三相步进电机驱动器SD-31007 低震动、低 ...","rating":"","subRankVOs":[],"type":1},{"rank":94,"landingPage":"http://www.yunkong.com/c_html_products/yk3605sa-22.html","label":"YK3605SA三相混合式小体积步进驱动器 - 步进电机驱动器","rating":"","subRankVOs":[],"type":1},{"rank":95,"landingPage":"http://www.onlinedown.net/soft/421782.htm","label":"森创SH-32206三相混合式步进电机驱动器说明书.. - 华军软件园","rating":"","subRankVOs":[],"type":1},{"rank":96,"landingPage":"http://www.agemotion.com/products/AHD8XXX/AHD81XX.html","label":"AHD80XX,AHD81XX-低压通用型步进电机驱动器-聚迅","rating":"","subRankVOs":[],"type":1},{"rank":97,"landingPage":"http://www.eeworld.com.cn/mndz/2011/0508/article_8223.html","label":"一种三相反应式步进电机驱动器设计方法 - 电子工程世界","rating":"","subRankVOs":[],"type":1},{"rank":98,"landingPage":"http://www.hanqiao.cc/product1.asp?tyc\u003d201272685455","label":"3HQ2280三相混合式步进电机驱动器 - 温州汉桥科技有限公司","rating":"","subRankVOs":[],"type":1},{"rank":99,"landingPage":"http://wx.adtechcn.com/product/product.php?t\u003d56byg-3","label":"56BYG系列三相步进电机- 众为兴产品中心","rating":"","subRankVOs":[],"type":1},{"rank":100,"landingPage":"http://www.jytjd.com/","label":"无锡交流伺服驱动器_无锡步进电机_无锡混合式步进电机_ ...","rating":"","subRankVOs":[],"type":1}]}
	public static String randomGet(String[] list) {
		int rtn = (int) (Math.random() * list.length);
		return list[rtn];
	}

	public static void main(String[] args) {
		int prefix=3;
		for(int i=9;i<12;i++)
		{
			System.out.println("hadoop fs -put ./"+i+" /data/myntest/jsondata_example"+prefix+".txt ");
			System.out.println("curl \"http://10.44.20.175:8080/insert?taskid="+i+"&hdfsfile=/data/myntest/jsondata_example"+prefix+".txt\"");
		}
	}
	
	public static void main2(String[] args) throws JSONException,
			InterruptedException {

		String[] landingPageList1 = { "www", "data", "baike", "ycloud",
				"rublour", "view", "star", "top", "topic", "about", "369",
				"jss", "eepw", "eepw", "eepw", "eepw", "eepw", "eepw", "pudn",
				"csdn", "java", "solr", "long", "equal" };
		String[] landingPageList2 = { "baidu", "sogou", "qq", "sohu", "sina",
				"tudou", "google", "yahoo", "alibaba", "taobao", "icloud",
				"ebay", "amazon", "ku6", "cctv", "iask", "zhihu" };
		String[] landingPageList3 = { "com", "cn", "net", "com.cn", "net.cn",
				"org" };
		String[] landingPageList4_filelist = { "jsp", "php", "html", "cgi",
				"htm", "txt" };
		String[] landingPageList5_urllist = { "id", "sql", "param", "session",
				"page", "username" };

		String[] labelList = { "三", "于", "干", "亏", "士", "工", "土", "才", "寸",
				"下", "大", "丈", "与", "万", "上", "小", "口", "巾", "山", "千", "乞",
				"川", "亿", "个", "勺", "久", "凡", "及", "夕", "丸", "么", "广", "亡",
				"门", "义", "之", "尸", "弓", "己", "已", "子", "卫", "也", "女", "飞",
				"刃", "习", "叉", "马", "乡", "四画", "丰", "王", "井", "开", "夫", "天",
				"无", "元", "专", "云", "扎", "艺", "木", "五", "支", "厅", "不", "太",
				"犬", "区", "历", "尤", "友", "匹", "车", "巨", "牙", "屯", "比", "互",
				"切", "瓦", "止", "少", "日", "中", "冈", "贝", "内", "水", "见", "午",
				"牛", "手", "毛", "气", "升", "长", "仁", "什", "片", "仆", "化", "仇",
				"币", "仍", "仅", "斤", "爪", "反", "介", "父", "从", "今", "凶", "分",
				"乏", "公", "仓", "月", "氏", "勿", "欠", "风", "丹", "匀", "乌", "凤",
				"勾", "文", "六", "方", "火", "为", "斗", "忆", "订", "计", "户", "认",
				"心", "尺", "引", "丑", "巴", "孔", "队", "办", "以", "允", "予", "劝",
				"双", "书", "幻", "五画", "玉", "刊", "示", "末", "未", "击", "打", "巧",
				"正", "扑", "扒", "功", "扔", "去", "甘", "世", "古", "节", "本", "术",
				"可", "丙", "左", "厉", "右", "石", "布", "龙", "平", "灭", "轧", "东",
				"卡", "北", "占", "业", "旧", "帅", "归", "且", "旦", "目", "叶", "甲",
				"申", "叮", "电", "号", "田", "由", "史", "只", "央", "兄", "叼", "叫",
				"另", "叨", "叹", "四", "生", "失", "禾", "丘", "付", "仗", "代", "仙",
				"们", "仪", "白", "仔", "他", "斥", "瓜", "乎", "丛", "令", "用", "甩",
				"印", "乐", "句", "匆", "册", "犯", "外", "处", "冬", "鸟", "务", "包",
				"饥", "主", "市", "立", "闪", "兰", "半", "汁", "汇", "头", "汉", "宁",
				"穴", "它", "讨", "写", "让", "礼", "训", "必", "议", "讯", "记", "永",
				"司", "尼", "民", "出", "辽", "奶", "奴", "加", "召", "皮", "边", "发",
				"孕", "圣", "对", "台", "矛", "纠", "母", "幼", "丝", "六画", "式", "刑",
				"动", "扛", "寺", "吉", "扣", "考", "托", "老", "执", "巩", "圾", "扩",
				"扫", "地", "扬", "场", "耳", "共", "芒", "亚", "芝", "朽", "朴", "机",
				"权", "过", "臣", "再", "协", "西", "压", "厌", "在", "有", "百", "存",
				"而", "页", "匠", "夸", "夺", "灰", "达", "列", "死", "成", "夹", "轨",
				"邪", "划", "迈", "毕", "至", "此", "贞", "师", "尘", "尖", "劣", "光",
				"当", "早", "吐", "吓", "虫", "曲", "团", "同", "吊", "吃", "因", "吸",
				"吗", "屿", "帆", "岁", "回", "岂", "刚", "则", "肉", "网", "年", "朱",
				"先", "丢", "舌", "竹", "迁", "乔", "伟", "传", "乒", "乓", "休", "伍",
				"伏", "优", "伐", "延", "件", "任", "伤", "价", "份", "华", "仰", "仿",
				"伙", "伪", "自", "血", "向", "似", "后", "行", "舟", "全", "会", "杀",
				"合", "兆", "企", "众", "爷", "伞", "创", "肌", "朵", "杂", "危", "旬",
				"旨", "负", "各", "名", "多", "争", "色", "壮", "冲", "冰", "庄", "庆",
				"亦", "刘", "齐", "交", "次", "衣", "产", "决", "充", "妄", "闭", "问",
				"闯", "羊", "并", "关", "米", "灯", "州", "汗", "污", "江", "池", "汤",
				"忙", "兴", "宇", "守", "宅", "字", "安", "讲", "军", "许", "论", "农",
				"讽", "设", "访", "寻", "那", "迅", "尽", "导", "异", "孙", "阵", "阳",
				"收", "阶", "阴", "防", "奸", "如", "妇", "好", "她", "妈", "戏", "羽",
				"观", "欢", "买", "红", "纤", "级", "约", "纪", "驰", "巡", "七画", "寿",
				"弄", "麦", "形", "进", "戒", "吞", "远", "违", "运", "扶", "抚", "坛",
				"技", "坏", "扰", "拒", "找", "批", "扯", "址", "走", "抄", "坝", "贡",
				"攻", "赤", "折", "抓", "扮", "抢", "孝", "均", "抛", "投", "坟", "抗",
				"坑", "坊", "抖", "护", "壳", "志", "扭", "块", "声", "把", "报", "却",
				"劫", "芽", "花", "芹", "芬", "苍", "芳", "严", "芦", "劳", "克", "苏",
				"杆", "杠", "杜", "材", "村", "杏", "极", "李", "杨", "求", "更", "束",
				"豆", "两", "丽", "医", "辰", "励", "否", "还", "歼", "来", "连", "步",
				"坚", "旱", "盯", "呈", "时", "吴", "助", "县", "里", "呆", "园", "旷",
				"围", "呀", "吨", "足", "邮", "男", "困", "吵", "串", "员", "听", "吩",
				"吹", "呜", "吧", "吼", "别", "岗", "帐", "财", "针", "钉", "告", "我",
				"乱", "利", "秃", "秀", "私", "每", "兵", "估", "体", "何", "但", "伸",
				"作", "伯", "伶", "佣", "低", "你", "住", "位", "伴", "身", "皂", "佛",
				"近", "彻", "役", "返", "余", "希", "坐", "谷", "妥", "含", "邻", "岔",
				"肝", "肚", "肠", "龟", "免", "狂", "犹", "角", "删", "条", "卵", "岛",
				"迎", "饭", "饮", "系", "言", "冻", "状", "亩", "况", "床", "库", "疗",
				"应", "冷", "这", "序", "辛", "弃", "冶", "忘", "闲", "间", "闷", "判",
				"灶", "灿", "弟", "汪", "沙", "汽", "沃", "泛", "沟", "没", "沈", "沉",
				"怀", "忧", "快", "完", "宋", "宏", "牢", "究", "穷", "灾", "良", "证",
				"启", "评", "补", "初", "社", "识", "诉", "诊", "词", "译", "君", "灵",
				"即", "层", "尿", "尾", "迟", "局", "改", "张", "忌", "际", "陆", "阿",
				"陈", "阻", "附", "妙", "妖", "妨", "努", "忍", "劲", "鸡", "驱", "纯",
				"纱", "纳", "纲", "驳", "纵", "纷", "纸", "纹", "纺", "驴", "纽", "八画",
				"奉", "玩", "环", "武", "青", "责", "现", "表", "规", "抹", "拢", "拔",
				"拣", "担", "坦", "押", "抽", "拐", "拖", "拍", "者", "顶", "拆", "拥",
				"抵", "拘", "势", "抱", "垃", "拉", "拦", "拌", "幸", "招", "坡", "披",
				"拨", "择", "抬", "其", "取", "苦", "若", "茂", "苹", "苗", "英", "范",
				"直", "茄", "茎", "茅", "林", "枝", "杯", "柜", "析", "板", "松", "枪",
				"构", "杰", "述", "枕", "丧", "或", "画", "卧", "事", "刺", "枣", "雨",
				"卖", "矿", "码", "厕", "奔", "奇", "奋", "态", "欧", "垄", "妻", "轰",
				"顷", "转", "斩", "轮", "软", "到", "非", "叔", "肯", "齿", "些", "虎",
				"虏", "肾", "贤", "尚", "旺", "具", "果", "味", "昆", "国", "昌", "畅",
				"明", "易", "昂", "典", "固", "忠", "咐", "呼", "鸣", "咏", "呢", "岸",
				"岩", "帖", "罗", "帜", "岭", "凯", "败", "贩", "购", "图", "钓", "制",
				"知", "垂", "牧", "物", "乖", "刮", "秆", "和", "季", "委", "佳", "侍",
				"供", "使", "例", "版", "侄", "侦", "侧", "凭", "侨", "佩", "货", "依",
				"的", "迫", "质", "欣", "征", "往", "爬", "彼", "径", "所", "舍", "金",
				"命", "斧", "爸", "采", "受", "乳", "贪", "念", "贫", "肤", "肺", "肢",
				"肿", "胀", "朋", "股", "肥", "服", "胁", "周", "昏", "鱼", "兔", "狐",
				"忽", "狗", "备", "饰", "饱", "饲", "变", "京", "享", "店", "夜", "庙",
				"府", "底", "剂", "郊", "废", "净", "盲", "放", "刻", "育", "闸", "闹",
				"郑", "券", "卷", "单", "炒", "炊", "炕", "炎", "炉", "沫", "浅", "法",
				"泄", "河", "沾", "泪", "油", "泊", "沿", "泡", "注", "泻", "泳", "泥",
				"沸", "波", "泼", "泽", "治", "怖", "性", "怕", "怜", "怪", "学", "宝",
				"宗", "定", "宜", "审", "宙", "官", "空", "帘", "实", "试", "郎", "诗",
				"肩", "房", "诚", "衬", "衫", "视", "话", "诞", "询", "该", "详", "建",
				"肃", "录", "隶", "居", "届", "刷", "屈", "弦", "承", "孟", "孤", "陕",
				"降", "限", "妹", "姑", "姐", "姓", "始", "驾", "参", "艰", "线", "练",
				"组", "细", "驶", "织", "终", "驻", "驼", "绍", "经", "贯", "九画", "奏",
				"春", "帮", "珍", "玻", "毒", "型", "挂", "封", "持", "项", "垮", "挎",
				"城", "挠", "政", "赴", "赵", "挡", "挺", "括", "拴", "拾", "挑", "指",
				"垫", "挣", "挤", "拼", "挖", "按", "挥", "挪", "某", "甚", "革", "荐",
				"巷", "带", "草", "茧", "茶", "荒", "茫", "荡", "荣", "故", "胡", "南",
				"药", "标", "枯", "柄", "栋", "相", "查", "柏", "柳", "柱", "柿", "栏",
				"树", "要", "咸", "威", "歪", "研", "砖", "厘", "厚", "砌", "砍", "面",
				"耐", "耍", "牵", "残", "殃", "轻", "鸦", "皆", "背", "战", "点", "临",
				"览", "竖", "省", "削", "尝", "是", "盼", "眨", "哄", "显", "哑", "冒",
				"映", "星", "昨", "畏", "趴", "胃", "贵", "界", "虹", "虾", "蚁", "思",
				"蚂", "虽", "品", "咽", "骂", "哗", "咱", "响", "哈", "咬", "咳", "哪",
				"炭", "峡", "罚", "贱", "贴", "骨", "钞", "钟", "钢", "钥", "钩", "卸",
				"缸", "拜", "看", "矩", "怎", "牲", "选", "适", "秒", "香", "种", "秋",
				"科", "重", "复", "竿", "段", "便", "俩", "贷", "顺", "修", "保", "促",
				"侮", "俭", "俗", "俘", "信", "皇", "泉", "鬼", "侵", "追", "俊", "盾",
				"待", "律", "很", "须", "叙", "剑", "逃", "食", "盆", "胆", "胜", "胞",
				"胖", "脉", "勉", "狭", "狮", "独", "狡", "狱", "狠", "贸", "怨", "急",
				"饶", "蚀", "饺", "饼", "弯", "将", "奖", "哀", "亭", "亮", "度", "迹",
				"庭", "疮", "疯", "疫", "疤", "姿", "亲", "音", "帝", "施", "闻", "阀",
				"阁", "差", "养", "美", "姜", "叛", "送", "类", "迷", "前", "首", "逆",
				"总", "炼", "炸", "炮", "烂", "剃", "洁", "洪", "洒", "浇", "浊", "洞",
				"测", "洗", "活", "派", "洽", "染", "济", "洋", "洲", "浑", "浓", "津",
				"恒", "恢", "恰", "恼", "恨", "举", "觉", "宣", "室", "宫", "宪", "突",
				"穿", "窃", "客", "冠", "语", "扁", "袄", "祖", "神", "祝", "误", "诱",
				"说", "诵", "垦", "退", "既", "屋", "昼", "费", "陡", "眉", "孩", "除",
				"险", "院", "娃", "姥", "姨", "姻", "娇", "怒", "架", "贺", "盈", "勇",
				"怠", "柔", "垒", "绑", "绒", "结", "绕", "骄", "绘", "给", "络", "骆",
				"绝", "绞", "统", "十画", "耕", "耗", "艳", "泰", "珠", "班", "素", "蚕",
				"顽", "盏", "匪", "捞", "栽", "捕", "振", "载", "赶", "起", "盐", "捎",
				"捏", "埋", "捉", "捆", "捐", "损", "都", "哲", "逝", "捡", "换", "挽",
				"热", "恐", "壶", "挨", "耻", "耽", "恭", "莲", "莫", "荷", "获", "晋",
				"恶", "真", "框", "桂", "档", "桐", "株", "桥", "桃", "格", "校", "核",
				"样", "根", "索", "哥", "速", "逗", "栗", "配", "翅", "辱", "唇", "夏",
				"础", "破", "原", "套", "逐", "烈", "殊", "顾", "轿", "较", "顿", "毙",
				"致", "柴", "桌", "虑", "监", "紧", "党", "晒", "眠", "晓", "鸭", "晃",
				"晌", "晕", "蚊", "哨", "哭", "恩", "唤", "啊", "唉", "罢", "峰", "圆",
				"贼", "贿", "钱", "钳", "钻", "铁", "铃", "铅", "缺", "氧", "特", "牺",
				"造", "乘", "敌", "秤", "租", "积", "秧", "秩", "称", "秘", "透", "笔",
				"笑", "笋", "债", "借", "值", "倚", "倾", "倒", "倘", "俱", "倡", "候",
				"俯", "倍", "倦", "健", "臭", "射", "躬", "息", "徒", "徐", "舰", "舱",
				"般", "航", "途", "拿", "爹", "爱", "颂", "翁", "脆", "脂", "胸", "胳",
				"脏", "胶", "脑", "狸", "狼", "逢", "留", "皱", "饿", "恋", "桨", "浆",
				"衰", "高", "席", "准", "座", "脊", "症", "病", "疾", "疼", "疲", "效",
				"离", "唐", "资", "凉", "站", "剖", "竞", "部", "旁", "旅", "畜", "阅",
				"羞", "瓶", "拳", "粉", "料", "益", "兼", "烤", "烘", "烦", "烧", "烛",
				"烟", "递", "涛", "浙", "涝", "酒", "涉", "消", "浩", "海", "涂", "浴",
				"浮", "流", "润", "浪", "浸", "涨", "烫", "涌", "悟", "悄", "悔", "悦",
				"害", "宽", "家", "宵", "宴", "宾", "窄", "容", "宰", "案", "请", "朗",
				"诸", "读", "扇", "袜", "袖", "袍", "被", "祥", "课", "谁", "调", "冤",
				"谅", "谈", "谊", "剥", "恳", "展", "剧", "屑", "弱", "陵", "陶", "陷",
				"陪", "娱", "娘", "通", "能", "难", "预", "桑", "绢", "绣", "验", "继" };

		for (int i = 0; i < 1000000; i++) {

			String strUrl = randomGet(landingPageList1) + "."
					+ randomGet(landingPageList2) + "."
					+ randomGet(landingPageList3);

			int reap = (int) (Math.random() * i % 20) + 1;

			for (int j = 0; j < reap; j++) {

				int count = (int) (Math.random() * i % 50) + 1;

				for (int k = 0; k < count; k++) {
					JSONObject json = new JSONObject();
					JSONObject data = new JSONObject();

					String subrank = "/" + randomGet(landingPageList4_filelist)
							+ "/" + randomGet(landingPageList5_urllist);
					data.put("rank", i * 10000 + j);
					data.put("domain", strUrl);
					data.put("landingPage", "http://" + strUrl + subrank);
					data.put("subRankParams", "http://" + strUrl + subrank
							+ "/" + count);

					String label = randomGet(labelList) + ""
							+ randomGet(labelList);
					data.put("label", label);
					data.put("subRankVOs", subrank);
					data.put("rating", reap);
					int type = (int) (Math.random() * i % 20) + 1;

					data.put("type", type);

					json.put("tablename", "ydb_example_rank");
					json.put("ydbpartion", "20151011");
					json.put("data", data);

					System.out.println(json);
				}

			}

		}

	}
}
