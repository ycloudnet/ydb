package cn.net.ycloud.ydb.server.reader.kafka;
import java.util.Date;
import java.util.Properties;
import java.util.Random;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;
import cn.net.ycloud.ydb.json.JSONException;
import cn.net.ydbmix.ydb.time.DateFormatUtils;
public class KafkaMakeSplitData {
//	public static void main(String[] args) throws UnsupportedEncodingException {
//		System.out.println(java.net.URLEncoder.encode("\001", "utf-8"));
//	}
	 public static void main(String[] args) throws JSONException, InterruptedException {
	        Random rnd = new Random();
	 
	        Properties props = new Properties();
	        String topic="ydbtest";
	        props.put("metadata.broker.list", "101.200.130.48:9092");
	        props.put("serializer.class", "kafka.serializer.StringEncoder");
	        props.put("partitioner.class", SimplePartitioner.class.getName());
	        props.put("request.required.acks", "1");
	        props.put("num.partition", "12");
	        
	 
	        ProducerConfig config = new ProducerConfig(props);
	 
	        Producer<String, String> producer = new Producer<String, String>(config);
	 

			for(int i=0;i<1;i++)
			{
				
				double sumuserage=0;
				double clickcount=0;
				double paymoney=0;
				double price=0;

				for(int j=0;j<1000000;j++)
				{
					
			
					sumuserage+=j%30+10;
					clickcount+=j%60;
					paymoney+=j%60+j*0.033;
					price+=j%30+j*0.03;

					StringBuffer buffer=new StringBuffer();
					buffer.append(1000000+j);//"indexnum"
					buffer.append(",").append("l_"+j%30);//label
					buffer.append(",").append("l_"+j%30);//userage
					buffer.append(",").append(j%60);//clickcount
					buffer.append(",").append(j%60+j*0.033);//paymoney
					buffer.append(",").append(j%30+j*0.03);//price
					buffer.append(",").append(j%15+" "+j%18+" "+j%14 +" joinyannian ");//content
					buffer.append(",").append(j%15+" "+j%18+" "+j%14 +" "+DateFormatUtils.DateFormat.get_yyyyMMddHHmmss().format(new Date(System.currentTimeMillis())));//contentcjk
					
		               String msg =buffer.toString(); 
		               KeyedMessage<String, String> kafkadata = new KeyedMessage<String, String>(topic, String.valueOf(rnd.nextInt(255)), msg);
		               producer.send(kafkadata);
		               if(j%1==0)
		               {
			               System.out.println(msg);
		               }
//		        Thread.sleep(10);
//					System.out.println();
				}
				System.out.println(i);
				System.out.println("sumuserage="+sumuserage);
				System.out.println("clickcount="+clickcount);
				System.out.println("paymoney="+paymoney);
				System.out.println("price="+price);

			}
		
	        
	        
       producer.close();
	    }
}
