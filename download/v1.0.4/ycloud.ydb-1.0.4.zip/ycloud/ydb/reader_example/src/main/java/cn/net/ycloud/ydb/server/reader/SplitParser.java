package cn.net.ycloud.ydb.server.reader;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.schema.IndexSchema;

import cn.net.ycloud.ydb.core.util.ParamsUitls;
import cn.net.ycloud.ydb.core.util.ParamsUitls.Lazy;
import cn.net.ycloud.ydb.utils.LogRate;
import cn.net.ycloud.ydb.utils.LogRatePool;
import cn.net.ycloud.ydb.utils.UniqConfig;
import cn.net.ycloud.ydb.utils.AsyncGet.SoftCachePool;
import cn.net.ydbmix.ydb.core.table.SchemaUtils;
import cn.net.ydbmix.ydb.time.DateFormatUtils;

public class SplitParser implements Parser{
    private static final Log LOG = LogFactory.getLog(SplitParser.class.getName());
    private  String split;
    private  String tablename;
    private  String partion;
    ArrayList<String> filelist;
	@Override
	public void init(String prefix,Map config, int readerIndex, int readerCount)
			throws IOException {
		this.split=java.net.URLDecoder.decode(String.valueOf(config.get("splitparser.split"+prefix)),"utf-8");
		this.tablename=String.valueOf(config.get("splitparser.tablename"+prefix));
		this.partion=String.valueOf(config.get("splitparser.partion.field"+prefix));
		final IndexSchema schma=IndexSchema.INSTANCE(SchemaUtils.schemaList(tablename,new String[0]));
		filelist=schma.getFieldNamelist();
		LOG.info("filelist:"+filelist.toString());
		
	}
	
	public static class Lazy {
		private  LogRate logIntervelNormal=LogRatePool.get();
		private  LogRate logIntervel=LogRatePool.get();
		private static Object LOCK = new Object();
		private static Lazy LAZYY =null;
		public static Lazy LAZY() {
			synchronized (LOCK) {
				if (LAZYY == null) {
					LAZYY = new Lazy();
				}

				return LAZYY;
			}
		}
	}
	
	
public static void main(String[] args) {
	String line=String.valueOf("2492,l_2,l_2,32,114.236,76.75999999999999,2 8 0 延云 ydb 延云  测试  中文分词 中华人民共和国 沈阳延云云计算技术有限公司,2 8 0 延云 ydb 延云  测试  中文分词 中华人民共和国 沈阳延云云计算技术有限公司");
	String[] values=line.split(",");
	
	System.out.println(Arrays.toString(values));
    ArrayList<String> filelist=new ArrayList<String>(Arrays.asList("indexnum,label,userage,clickcount,paymoney,price,content,contentcjk".split(",")));

	HashMap<String, Object> data=new HashMap<String, Object>(values.length+2); 
	for(int i=0;i<values.length&&i<filelist.size(); i++){
		
		String fieldname=filelist.get(i);
		System.out.println(fieldname);
		if(fieldname.equals("ydb_parse_end"))
		{
			break;
		}
		
		if(fieldname.equals("ydb_rawdata"))
		{
			data.put(fieldname, String.valueOf(line));
		}else{
			data.put(fieldname, values[i]);
		}
	}
	
	System.out.println(data);
}



	@Override
	public YdbParse parse(Object raw) throws Throwable {
		try{
			String line=String.valueOf(raw);
			String[] values=line.split(this.split);
			
			HashMap<String, Object> data=new HashMap<String, Object>(values.length+2); 
			for(int i=0;i<values.length&&i<filelist.size(); i++){
				
				String fieldname=filelist.get(i);
				if(fieldname.equals("ydb_parse_end"))
				{
					break;
				}
				
				if(fieldname.equals("ydb_rawdata"))
				{
					data.put(fieldname, String.valueOf(raw));
				}else{
					data.put(fieldname, values[i]);
				}
			}
			
			
			String partion="default";
			if(this.partion.startsWith("ydbparse_"))
			{
				if(this.partion.equals("ydbparse_yyyyMMdd"))
				{
					partion=DateFormatUtils.DateFormat.get_yyyyMMdd().format(new Date(System.currentTimeMillis()));
				}else if(this.partion.equals("ydbparse_default"))
				{
					partion="default";
				}else if(this.partion.equals("ydbparse_yyyyMM"))
				{
					partion=DateFormatUtils.DateFormat.get_yyyyMM().format(new Date(System.currentTimeMillis()));
				}
				else if(this.partion.equals("ydbparse_yyyy"))
				{
					partion=DateFormatUtils.DateFormat.get_yyyy().format(new Date(System.currentTimeMillis()));
				}
			}else{
				partion=String.valueOf(data.get(this.partion));
			}
			
			if(partion==null)
			{
				partion="default";
			}
			
			
			YdbParseItem item=new YdbParseItem(data, this.tablename, partion, line.length());
			if(Lazy.LAZY().logIntervel.allowlog())
			{
				LOG.info("parse YdbParseItem this.split:"+this.split+"="+item.toString()+","+raw);

			}
			
			return new YdbParse(true, new YdbParseItem[]{item});
			
		}catch(Throwable e)
		{
			if(Lazy.LAZY().logIntervelNormal.allowlog())
			{
				LOG.error("parse error",e);
			}
		}
		
		return new YdbParse(false, new YdbParseItem[0]);
	}

}
