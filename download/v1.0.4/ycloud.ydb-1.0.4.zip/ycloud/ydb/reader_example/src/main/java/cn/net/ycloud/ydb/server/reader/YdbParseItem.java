package cn.net.ycloud.ydb.server.reader;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class YdbParseItem {

	String tableName;
	String partion;
	int datasize;
	
	@Override
	public String toString() {
		return "YdbParseItem [tableName=" + tableName + ", partion=" + partion
				+ ", datasize=" + datasize + ", doc=" + doc + ", addIndex="
				+ addIndex + ", cleanMatch=" + cleanMatch + "]";
	}

	private Map<String,Object> doc=new HashMap<String, Object>();

	public Map<String,String> getAddIndex() {
		return addIndex;
	}



	public YdbParseItem(Map<String,String> addIndex,List<String> cleanMatch,String tableName,
			String partion, int datasize) {
		super();
		this.cleanMatch=cleanMatch;
		this.addIndex = addIndex;
		this.doc = new HashMap<String, Object>();
		this.tableName = tableName;
		this.partion = partion;
		this.datasize = datasize;
	}
	
	private Map<String,String> addIndex=null;
	private List<String> cleanMatch=null;


	public List<String> getCleanMatch() {
		return cleanMatch;
	}



	public YdbParseItem(Map<String, Object> doc, String tableName,
			String partion, int datasize) {
		super();
		this.doc = doc;
		this.tableName = tableName;
		this.partion = partion;
		this.datasize = datasize;
	}
	
	public Map<String, Object> getDoc() {
		return doc;
	}
	public String getTableName() {
		return tableName;
	}
	public String getPartion() {
		return partion;
	}
	
	public int getDatasize() {
		return datasize;
	}
	
	



}
