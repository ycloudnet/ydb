package cn.net.ycloud.ydb.server.reader;

public class YdbParse {
	
	public static YdbParse FAIL=new YdbParse(false, new YdbParseItem[0]);
	public YdbParse(boolean isvalidate, YdbParseItem[] data) {
		this.isvalidate = isvalidate;
		this.data = data;
	}
	public boolean isvalidate() {
		return isvalidate;
	}
	public YdbParseItem[] getData() {
		return data;
	}
	public boolean isvalidate;
	public YdbParseItem[] data;

}
