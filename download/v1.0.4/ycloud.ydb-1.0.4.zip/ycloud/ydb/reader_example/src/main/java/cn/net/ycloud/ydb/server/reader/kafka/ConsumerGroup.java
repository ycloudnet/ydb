package cn.net.ycloud.ydb.server.reader.kafka;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import kafka.consumer.ConsumerConfig;
import kafka.consumer.KafkaStream;
import kafka.javaapi.consumer.ConsumerConnector;

public class ConsumerGroup {
    private static final Log LOG = LogFactory.getLog(ConsumerGroup.class.getName());

   private final ConsumerConnector consumer;
   private final String topic;
   private  ExecutorService executor;

   public ConsumerGroup(String a_zookeeper, String a_groupId, String a_topic,String reset) {
       consumer = kafka.consumer.Consumer.createJavaConsumerConnector(
               createConsumerConfig(a_zookeeper, a_groupId,reset));
       this.topic = a_topic;
   }

   public void shutdown() {
       if (consumer != null) consumer.shutdown();
       if (executor != null) executor.shutdown();
       try {
           if (!executor.awaitTermination(5000, TimeUnit.MILLISECONDS)) {
               LOG.info("Timed out waiting for consumer threads to shut down, exiting uncleanly");
           }
       } catch (InterruptedException e) {
           LOG.info("Interrupted during shutdown, exiting uncleanly");
       }
  }

   public void run(KafkaDataReader reader,int a_numThreads) {
       LOG.info("kafka.run a_numThreads:"+ a_numThreads);

       Map<String, Integer> topicCountMap = new HashMap<String, Integer>();
       topicCountMap.put(topic, new Integer(a_numThreads));
       Map<String, List<KafkaStream<byte[], byte[]>>> consumerMap = consumer.createMessageStreams(topicCountMap);
       List<KafkaStream<byte[], byte[]>> streams = consumerMap.get(topic);

       // now launch all the threads
       //
       executor = Executors.newFixedThreadPool(a_numThreads);

       LOG.info("kafka.run luntch a_numThreads:"+ a_numThreads);

       int threadNumber = 0;
       for (final KafkaStream stream : streams) {
           executor.submit(new ConsumerRunable(reader,stream, threadNumber));
           threadNumber++;
       }
   }

   private static ConsumerConfig createConsumerConfig(String a_zookeeper, String a_groupId,String reset) {
       Properties props = new Properties();
       props.put("zookeeper.connect", a_zookeeper);
       props.put("group.id", a_groupId);
       props.put("zookeeper.session.timeout.ms", "40000");
       props.put("zookeeper.sync.time.ms", "500");
       props.put("auto.commit.interval.ms", "2000");
       props.put("auto.offset.reset", reset);

       LOG.info("kafka.config"+props.toString());
       return new ConsumerConfig(props);
   }


}
