package cn.net.ycloud.ydb.server.reader;

import java.io.IOException;
import java.util.Map;


public interface Parser  {
	public  abstract void init(String prefix,Map config, 
		     int readerIndex, int readerCount)
   throws IOException;
	public YdbParse parse(Object raw) throws Throwable;
}